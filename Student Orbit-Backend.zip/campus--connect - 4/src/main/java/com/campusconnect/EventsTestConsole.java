import com.mongodb.client.*;
import org.bson.Document;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class EventsTestConsole {
    public static void main(String[] args) {
        try (MongoClient mongoClient = MongoClients.create("mongodb://localhost:27017")) {

            MongoDatabase database = mongoClient.getDatabase("campusconnect");
            MongoCollection<Document> eventsCollection = database.getCollection("events");
            MongoCollection<Document> rsvpCollection = database.getCollection("rsvp");

            DateTimeFormatter formatter = DateTimeFormatter.ISO_DATE_TIME;

            // Event 1: AI Workshop
            Document query1 = new Document("title", "AI Workshop")
                    .append("date", "2025-07-20")
                    .append("location", "Auditorium A");

            Document event1 = eventsCollection.find(query1).first();

            if (event1 == null) {
                event1 = new Document("title", "AI Workshop")
                        .append("desc", "A beginner's workshop on AI and ML.")
                        .append("date", "2025-07-20")
                        .append("time", "10:00 AM")
                        .append("department", "comp-sci")
                        .append("level", "UG")
                        .append("location", "Auditorium A")
                        .append("image", "https://www.bethlehem.edu/wp-content/uploads/2022/03/ai-1.png")
                        .append("startDate", "2025-07-20T10:00:00")
                        .append("endDate", "2025-07-20T13:00:00")
                        .append("registrationStart", "2025-07-10T09:00:00")
                        .append("registrationEnd", "2025-07-19T23:59:59");

                eventsCollection.insertOne(event1);
                System.out.println("✅ Inserted new event:\n" + event1.toJson());
            } else {
                System.out.println("⚠️ Event already exists:\n" + event1.toJson());
            }

            // Event 2: SQL Workshop
            Document query2 = new Document("title", "SQL Workshop")
                    .append("date", "2025-07-20")
                    .append("location", "Auditorium B");

            Document event2 = eventsCollection.find(query2).first();

            if (event2 == null) {
                event2 = new Document("title", "SQL Workshop")
                        .append("desc", "A beginner's workshop on MYSQL and SQL.")
                        .append("date", "2025-07-20")
                        .append("time", "10:00 AM")
                        .append("department", "comp-sci")
                        .append("level", "UG")
                        .append("location", "Auditorium B")
                        .append("image", "https://innozant.com/classes/wp-content/uploads/2025/01/ORACLE-SQL-1.png")
                        .append("startDate", "2025-07-20T10:00:00")
                        .append("endDate", "2025-07-20T13:00:00")
                        .append("registrationStart", "2025-07-10T09:00:00")
                        .append("registrationEnd", "2025-07-19T23:59:59");

                eventsCollection.insertOne(event2);
                System.out.println("✅ Inserted new event:\n" + event2.toJson());
            } else {
                System.out.println("⚠️ Event already exists:\n" + event2.toJson());
            }

            // Insert RSVP for event 1
            String eventId = event1.getObjectId("_id").toHexString();

            Document rsvpQuery = new Document("eventId", eventId)
                    .append("email", "john@example.com");

            Document existingRSVP = rsvpCollection.find(rsvpQuery).first();

            if (existingRSVP == null) {
                Document rsvp = new Document("eventId", eventId)
                        .append("fullName", "John Doe")
                        .append("email", "john@example.com")
                        .append("status", "going");

                rsvpCollection.insertOne(rsvp);
                System.out.println("✅ Inserted RSVP:\n" + rsvp.toJson());
            } else {
                System.out.println("⚠️ RSVP already exists:\n" + existingRSVP.toJson());
            }

        } catch (Exception e) {
            System.err.println("❌ Error: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
