package com.campusconnect.handlers;

import com.campusconnect.util.JsonUtil;
import com.campusconnect.util.OtpStore;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class VerifyCodeHandler implements HttpHandler {

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        if (!exchange.getRequestMethod().equalsIgnoreCase("POST")) {
            exchange.sendResponseHeaders(405, -1);
            return;
        }

        ObjectMapper mapper = new ObjectMapper();
        InputStreamReader reader = new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8);
        Map<String, Object> body = mapper.readValue(reader, Map.class);

        String email = (String) body.get("email");
        String code = (String) body.get("code");

        if (email == null || code == null) {
            Map<String, Object> error = new HashMap<>();
            error.put("message", "Email and code are required");
            JsonUtil.sendJsonResponse(exchange, 400, error);
            return;
        }

        String storedOtp = OtpStore.getOtp(email);

        Map<String, Object> response = new HashMap<>();
        if (storedOtp != null && storedOtp.equals(code)) {
            response.put("message", "OTP verified successfully");
            JsonUtil.sendJsonResponse(exchange, 200, response);
        } else {
            response.put("message", "Invalid OTP");
            JsonUtil.sendJsonResponse(exchange, 401, response);
        }
    }
}
