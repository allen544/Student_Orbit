package com.campusconnect.handlers;

import com.campusconnect.model.Event;
import com.campusconnect.service.EventService;
import com.campusconnect.util.JsonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Collections;

public class UpdateEventHandler implements HttpHandler {

    private final EventService eventService = new EventService();
    private final ObjectMapper mapper = new ObjectMapper();

    @Override
    public void handle(HttpExchange exchange) {
        try {
            if (!"PUT".equalsIgnoreCase(exchange.getRequestMethod())) {
                JsonUtil.sendJsonResponse(exchange, 405, Collections.singletonMap("error", "Method Not Allowed"));
                return;
            }

            String path = exchange.getRequestURI().getPath();
            String eventId = path.substring(path.lastIndexOf("/") + 1);

            Event updatedEvent = mapper.readValue(
                    new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8),
                    Event.class
            );

            boolean updated = eventService.updateEvent(eventId, updatedEvent);
            if (updated) {
                JsonUtil.sendJsonResponse(exchange, 200, Collections.singletonMap("message", "Event updated successfully"));
            } else {
                JsonUtil.sendJsonResponse(exchange, 500, Collections.singletonMap("error", "Failed to update event"));
            }

        } catch (Exception e) {
            e.printStackTrace();
            try {
                JsonUtil.sendJsonResponse(exchange, 500, Collections.singletonMap("error", "Internal server error"));
            } catch (Exception ignored) {}
        }
    }
}
