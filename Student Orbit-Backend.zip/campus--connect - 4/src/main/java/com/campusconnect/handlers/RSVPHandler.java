package com.campusconnect.handlers;

import com.campusconnect.service.RSVPService;
import com.campusconnect.util.JsonUtil;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.util.Map;

public class RSVPHandler implements HttpHandler {

    private final RSVPService rsvpService = new RSVPService();

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        JsonUtil.sendCorsHeaders(exchange);

        if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(204, -1);
            return;
        }

        if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
            Map<String, Object> data = JsonUtil.parseRequestBody(exchange);
            String response = rsvpService.handleRSVP(data);
            JsonUtil.sendJsonResponse(exchange, Map.of("message", response));
        } else {
            JsonUtil.sendErrorResponse(exchange, 405, "Method Not Allowed");
        }
    }
}
