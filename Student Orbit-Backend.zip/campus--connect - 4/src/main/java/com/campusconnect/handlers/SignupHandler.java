package com.campusconnect.handlers;

import com.campusconnect.model.User;
import com.campusconnect.service.AuthService;
import com.campusconnect.util.JsonUtil;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class SignupHandler implements HttpHandler {
    private final AuthService authService = new AuthService(); // ✅ Injected service

    @Override
    public void handle(HttpExchange exchange) {
        try {
            exchange.getResponseHeaders().set("Content-Type", "application/json");

            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                String errorResponse = "{\"message\":\"Method not allowed\"}";
                exchange.sendResponseHeaders(405, errorResponse.getBytes().length);
                OutputStream os = exchange.getResponseBody();
                os.write(errorResponse.getBytes());
                os.close();
                return;
            }

            System.out.println("📥 Signup request received");

            ObjectMapper mapper = new ObjectMapper();
            InputStreamReader reader = new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8);
            User user = mapper.readValue(reader, User.class);

            System.out.println("Parsed user: " + user.getEmail());

            // ✅ Use AuthService to handle registration (includes hashing)
            String message = authService.registerUser(user);

            if ("User already exists with this email.".equals(message)) {
                System.out.println("❗ Existing user: " + user.getEmail());
            } else {
                System.out.println("✅ Inserted user: " + user.getEmail());
            }

            String responseJson = "{\"message\":\"" + message + "\"}";
            exchange.sendResponseHeaders(200, responseJson.getBytes().length);
            OutputStream os = exchange.getResponseBody();
            os.write(responseJson.getBytes());
            os.close();
            System.out.println("✅ Sending signup response: " + responseJson);

        } catch (Exception e) {
            System.err.println("❌ Exception in SignupHandler: " + e.getMessage());
            e.printStackTrace();
            try {
                String err = "{\"message\":\"Internal Server Error\"}";
                exchange.getResponseHeaders().set("Content-Type", "application/json");
                exchange.sendResponseHeaders(500, err.getBytes().length);
                OutputStream os = exchange.getResponseBody();
                os.write(err.getBytes());
                os.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
