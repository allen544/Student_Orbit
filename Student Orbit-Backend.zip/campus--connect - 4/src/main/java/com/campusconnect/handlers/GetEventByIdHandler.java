package com.campusconnect.handlers;

import com.campusconnect.model.Event;
import com.campusconnect.service.EventService;
import com.campusconnect.util.JsonUtil;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.OutputStream;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.Map;

public class GetEventByIdHandler implements HttpHandler {

    private final EventService eventService = new EventService();

    @Override
    public void handle(HttpExchange exchange) {
        try {
            addCORSHeaders(exchange);

            if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(204, -1); // Preflight response
                return;
            }

            if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(405, -1); // Method Not Allowed
                return;
            }

            URI requestURI = exchange.getRequestURI();
            String path = requestURI.getPath(); // /events/{id}
            String[] parts = path.split("/");

            if (parts.length < 3) {
                String response = "{\"error\": \"Event ID missing in path.\"}";
                exchange.sendResponseHeaders(400, response.length());
                exchange.getResponseBody().write(response.getBytes(StandardCharsets.UTF_8));
                return;
            }

            String eventId = parts[2];
            Event event = eventService.getEventById(eventId);

            if (event == null) {
                String response = "{\"error\": \"Event not found\"}";
                exchange.sendResponseHeaders(404, response.length());
                exchange.getResponseBody().write(response.getBytes(StandardCharsets.UTF_8));
                return;
            }

            String jsonResponse = JsonUtil.toJson(Map.of("event", event));
            exchange.getResponseHeaders().add("Content-Type", "application/json");
            exchange.sendResponseHeaders(200, jsonResponse.getBytes().length);
            OutputStream os = exchange.getResponseBody();
            os.write(jsonResponse.getBytes(StandardCharsets.UTF_8));
            os.close();

        } catch (Exception e) {
            e.printStackTrace();
            String response = "{\"error\":\"Internal Server Error\"}";
            try {
                exchange.sendResponseHeaders(500, response.length());
                exchange.getResponseBody().write(response.getBytes(StandardCharsets.UTF_8));
                exchange.getResponseBody().close();
            } catch (Exception ignored) {}
        }
    }

    private void addCORSHeaders(HttpExchange exchange) {
        exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        exchange.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type,Authorization");
    }
}
