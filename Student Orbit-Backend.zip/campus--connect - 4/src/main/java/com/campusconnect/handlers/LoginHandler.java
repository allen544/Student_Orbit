package com.campusconnect.handlers;

import com.campusconnect.db.MongoConnector;
import com.campusconnect.model.User;
import com.campusconnect.model.LoginSuccessResponse;
import com.campusconnect.util.JsonUtil;
import com.campusconnect.util.PasswordUtil; // ✅ Password utility for hash check
import com.mongodb.client.MongoCollection;
import org.bson.Document;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class LoginHandler implements HttpHandler {
    @Override
    public void handle(HttpExchange exchange) {
        try {
            exchange.getResponseHeaders().set("Content-Type", "application/json");

            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                String errorResponse = "{\"message\":\"Method not allowed\"}";
                exchange.sendResponseHeaders(405, errorResponse.getBytes().length);
                OutputStream os = exchange.getResponseBody();
                os.write(errorResponse.getBytes());
                os.close();
                return;
            }

            // Parse the login request (email + password)
            ObjectMapper mapper = new ObjectMapper();
            InputStreamReader reader = new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8);
            User loginUser = mapper.readValue(reader, User.class);

            // Find user by email only
            MongoCollection<Document> collection = MongoConnector.getDatabase().getCollection("users");
            Document found = collection.find(
                    new Document("email", loginUser.getEmail())
            ).first();

            String json;
            OutputStream os = exchange.getResponseBody();

            // Check if user found and password matches hashed password
            if (found != null && PasswordUtil.checkPassword(loginUser.getPassword(), found.getString("password"))) {
                System.out.println("✅ Login matched for: " + loginUser.getEmail());

                // Prepare success response
                LoginSuccessResponse successResponse = new LoginSuccessResponse(
                        "dummy-token",
                        found.getObjectId("_id").toHexString(),
                        found.getString("fullName"),
                        found.getString("email"),
                        found.getString("department"),
                        found.getString("semester")
                );

                json = mapper.writeValueAsString(successResponse);
                exchange.sendResponseHeaders(200, json.getBytes().length);
                System.out.println("✅ Sending success response: " + json);
            } else {
                System.out.println("❌ Login failed for: " + loginUser.getEmail());
                json = "{\"message\":\"Invalid credentials\"}";
                exchange.sendResponseHeaders(401, json.getBytes().length);
                System.out.println("❌ Sending error response: " + json);
            }

            os.write(json.getBytes());
            os.close();

        } catch (Exception e) {
            System.err.println("❌ Exception in LoginHandler: " + e.getMessage());
            e.printStackTrace();
            try {
                String err = "{\"message\":\"Internal Server Error\"}";
                exchange.sendResponseHeaders(500, err.getBytes().length);
                OutputStream os = exchange.getResponseBody();
                os.write(err.getBytes());
                os.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
