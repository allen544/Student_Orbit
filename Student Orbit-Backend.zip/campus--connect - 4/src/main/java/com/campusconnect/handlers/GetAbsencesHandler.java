package com.campusconnect.handlers;

import com.campusconnect.db.MongoConnector;
import com.campusconnect.util.JsonUtil;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import org.bson.Document;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class GetAbsencesHandler implements HttpHandler {

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        // ✅ Handle preflight request
        if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
            JsonUtil.sendCorsHeaders(exchange);
            exchange.sendResponseHeaders(204, -1); // No content
            return;
        }

        JsonUtil.sendCorsHeaders(exchange); // ✅ Always send CORS headers

        if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
            JsonUtil.sendErrorResponse(exchange, 405, "Method Not Allowed");
            return;
        }

        try {
            MongoDatabase db = MongoConnector.getDatabase();
            MongoCollection<Document> absences = db.getCollection("leave_applications");

            List<Document> result = absences.find().into(new ArrayList<>());
            JsonUtil.sendJsonResponse(exchange, 200, result);

        } catch (Exception e) {
            e.printStackTrace();
            JsonUtil.sendErrorResponse(exchange, 500, "Internal Server Error");
        }
    }
}
