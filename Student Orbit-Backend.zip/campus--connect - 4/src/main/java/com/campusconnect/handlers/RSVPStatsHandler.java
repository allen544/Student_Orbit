package com.campusconnect.handlers;

import com.campusconnect.util.JsonUtil;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.campusconnect.db.MongoConnector;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import org.bson.Document;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class RSVPStatsHandler implements HttpHandler {

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        // Optional: Add CORS headers
        addCorsHeaders(exchange);

        if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
            JsonUtil.sendJsonResponse(exchange, 405, "Method Not Allowed");
            return;
        }

        try {
            String path = exchange.getRequestURI().getPath();
            String eventId = path.substring(path.lastIndexOf("/") + 1);

            MongoDatabase db = MongoConnector.getDatabase();
            MongoCollection<Document> rsvpCollection = db.getCollection("rsvps");

            long goingCount = rsvpCollection.countDocuments(Filters.and(
                    Filters.eq("eventId", eventId),
                    Filters.eq("status", "going")
            ));

            long totalRSVPs = rsvpCollection.countDocuments(Filters.eq("eventId", eventId));

            Map<String, Object> response = new HashMap<>();
            response.put("total", totalRSVPs);
            response.put("going", goingCount);
            response.put("notGoing", totalRSVPs - goingCount);

            JsonUtil.sendJsonResponse(exchange, 200, response);

        } catch (Exception e) {
            e.printStackTrace();
            JsonUtil.sendJsonResponse(exchange, 500, "Internal server error");
        }
    }

    private void addCorsHeaders(HttpExchange exchange) {
        exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().add("Access-Control-Allow-Methods", "GET, OPTIONS");
        exchange.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");
    }
}
