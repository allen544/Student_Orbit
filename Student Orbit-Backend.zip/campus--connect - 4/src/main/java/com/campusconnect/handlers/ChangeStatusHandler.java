package com.campusconnect.handlers;

import com.campusconnect.service.EventService;
import com.campusconnect.util.JsonUtil;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class ChangeStatusHandler implements HttpHandler {

    private final EventService eventService = new EventService();
    private final ObjectMapper mapper = new ObjectMapper();

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        addCorsHeaders(exchange); // Optional: for Angular dev

        if (!"PATCH".equalsIgnoreCase(exchange.getRequestMethod())) {
            JsonUtil.sendJsonResponse(exchange, 405, "Method Not Allowed");
            return;
        }

        try {
            String path = exchange.getRequestURI().getPath();
            String eventId = path.substring(path.lastIndexOf("/") + 1);

            JsonNode body = mapper.readTree(new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8));

            if (body == null || !body.hasNonNull("status")) {
                JsonUtil.sendJsonResponse(exchange, 400, "Missing 'status' field");
                return;
            }

            String status = body.get("status").asText();

            boolean updated = eventService.updateStatus(eventId, status);
            if (updated) {
                JsonUtil.sendJsonResponse(exchange, 200, "Status updated to: " + status);
            } else {
                JsonUtil.sendJsonResponse(exchange, 500, "Failed to update status");
            }
        } catch (Exception e) {
            e.printStackTrace();
            JsonUtil.sendJsonResponse(exchange, 500, "Internal server error");
        }
    }

    private void addCorsHeaders(HttpExchange exchange) {
        exchange.getResponseHeaders().add("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().add("Access-Control-Allow-Methods", "PATCH, OPTIONS");
        exchange.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");
    }
}
