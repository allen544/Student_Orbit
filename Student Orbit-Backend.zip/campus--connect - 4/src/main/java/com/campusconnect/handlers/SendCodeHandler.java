package com.campusconnect.handlers;

import com.campusconnect.util.EmailUtil;
import com.campusconnect.util.JsonUtil;
import com.campusconnect.util.OtpStore;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import javax.mail.MessagingException;
import java.io.IOException;
import java.util.Map;
import java.util.HashMap;
import java.util.Random;

public class SendCodeHandler implements HttpHandler {

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        System.out.println("Received request to send OTP"); // Debug log

        if (!exchange.getRequestMethod().equalsIgnoreCase("POST")) {
            System.out.println("Method not allowed"); // Debug log
            exchange.sendResponseHeaders(405, -1);
            return;
        }

        try {
            Map<String, Object> body = JsonUtil.parseRequestBody(exchange);
            System.out.println("Parsed request body: " + body); // Debug log

            String email = (String) body.get("email");
            System.out.println("Email from request: " + email); // Debug log

            if (email == null || email.trim().isEmpty()) {
                System.out.println("Email is empty"); // Debug log
                Map<String, Object> errorResponse = new HashMap<>();
                errorResponse.put("message", "Email is required");
                JsonUtil.sendJsonResponse(exchange, 400, errorResponse);
                return;
            }

            String otp = String.format("%06d", new Random().nextInt(999999));
            System.out.println("Generated OTP for " + email + ": " + otp);

            OtpStore.storeOtp(email, otp);
            System.out.println("OTP stored for email: " + email);

            try {
                System.out.println("Attempting to send email...");
                EmailUtil.sendOtpEmail(email, otp);
                System.out.println("Email sent successfully");

                Map<String, Object> successResponse = new HashMap<>();
                successResponse.put("message", "OTP sent successfully");
                JsonUtil.sendJsonResponse(exchange, 200, successResponse);
            } catch (MessagingException e) {
                System.err.println("❌ Email sending failed: " + e.getMessage());
                e.printStackTrace(); // Full stack trace

                Map<String, Object> errorResponse = new HashMap<>();
                errorResponse.put("message", "Failed to send OTP email");
                JsonUtil.sendJsonResponse(exchange, 500, errorResponse);
            }
        } catch (Exception e) {
            System.err.println("❌ Error in SendCodeHandler: " + e.getMessage());
            e.printStackTrace();

            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("message", "Internal server error");
            JsonUtil.sendJsonResponse(exchange, 500, errorResponse);
        }
    }
}