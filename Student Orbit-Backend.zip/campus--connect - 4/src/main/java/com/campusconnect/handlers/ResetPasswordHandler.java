package com.campusconnect.handlers;

import com.campusconnect.db.MongoConnector;
import com.campusconnect.util.JsonUtil;
import com.campusconnect.util.OtpStore;
import com.campusconnect.util.PasswordUtil;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.model.Filters;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.bson.Document;

import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

public class ResetPasswordHandler implements HttpHandler {

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        if (!exchange.getRequestMethod().equalsIgnoreCase("POST")) {
            exchange.sendResponseHeaders(405, -1);
            return;
        }

        ObjectMapper mapper = new ObjectMapper();
        InputStreamReader reader = new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8);

        // ✅ Fixed generics warning by defining proper type
        Map<String, Object> body = mapper.readValue(reader, mapper.getTypeFactory().constructMapType(Map.class, String.class, Object.class));

        String email = (String) body.get("email");
        String newPassword = (String) body.get("newPassword");

        if (email == null || newPassword == null || newPassword.length() < 8) {
            Map<String, Object> error = new HashMap<>();
            error.put("message", "Invalid email or password");
            JsonUtil.sendJsonResponse(exchange, 400, error);
            return;
        }

        MongoCollection<Document> users = MongoConnector.getDatabase().getCollection("users");
        Document userDoc = users.find(Filters.eq("email", email)).first();

        if (userDoc == null) {
            Map<String, Object> notFound = new HashMap<>();
            notFound.put("message", "User not found");
            JsonUtil.sendJsonResponse(exchange, 404, notFound);
            return;
        }

        String hashedPassword = PasswordUtil.hashPassword(newPassword);
        users.updateOne(Filters.eq("email", email), new Document("$set", new Document("password", hashedPassword)));

        OtpStore.removeOtp(email);

        Map<String, Object> success = new HashMap<>();
        success.put("message", "Password reset successful");
        JsonUtil.sendJsonResponse(exchange, 200, success);
    }
}
