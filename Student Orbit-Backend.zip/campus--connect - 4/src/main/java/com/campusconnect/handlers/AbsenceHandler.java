package com.campusconnect.handlers;

import com.campusconnect.db.MongoConnector;
import com.campusconnect.util.JsonUtil;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import org.bson.Document;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class AbsenceHandler implements HttpHandler {
    @Override
    public void handle(HttpExchange exchange) throws IOException {
        JsonUtil.sendCorsHeaders(exchange);

        if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(204, -1);
            return;
        }

        if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
            JsonUtil.sendJsonResponse(exchange, 405, "Method Not Allowed");
            return;
        }

        try {
            MongoDatabase db = MongoConnector.getDatabase();
            MongoCollection<Document> collection = db.getCollection("absence_requests");

            List<Document> requests = collection.find().into(new ArrayList<>());

            JsonUtil.sendJsonResponse(exchange, 200, requests);
        } catch (Exception e) {
            e.printStackTrace();
            JsonUtil.sendJsonResponse(exchange, 500, "Failed to fetch absence requests");
        }
    }
}
