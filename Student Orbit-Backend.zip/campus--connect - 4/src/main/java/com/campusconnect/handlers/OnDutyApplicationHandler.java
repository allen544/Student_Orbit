package com.campusconnect.handlers;

import com.campusconnect.model.OnDutyApplication;
import com.campusconnect.service.ApplicationService;
import com.campusconnect.util.JsonUtil;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

public class OnDutyApplicationHandler implements HttpHandler {
    private final ApplicationService applicationService = new ApplicationService();

    @Override
    public void handle(HttpExchange exchange) {
        System.out.println("📩 On-duty application request received");

        if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
            try {
                JsonUtil.sendMethodNotAllowed(exchange);
            } catch (Exception e) {
                System.err.println("❌ Error sending 405 response: " + e.getMessage());
            }
            return;
        }

        try {
            OnDutyApplication app = JsonUtil.fromJson(
                    new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8),
                    OnDutyApplication.class
            );

            applicationService.saveOnDutyApplication(app);

            String response = "{\"message\":\"On-duty application saved successfully\"}";
            exchange.getResponseHeaders().set("Content-Type", "application/json");

            System.out.println("✅ Responding to on-duty application");

            exchange.sendResponseHeaders(200, response.length());
            exchange.getResponseBody().write(response.getBytes(StandardCharsets.UTF_8));
            exchange.getResponseBody().close();

        } catch (Exception e) {
            System.err.println("❌ Error in OnDutyApplicationHandler: " + e.getMessage());
            e.printStackTrace();
            try {
                String errorResponse = "{\"error\":\"Internal Server Error\"}";
                exchange.sendResponseHeaders(500, errorResponse.length());
                exchange.getResponseBody().write(errorResponse.getBytes(StandardCharsets.UTF_8));
                exchange.getResponseBody().close();
            } catch (Exception ignored) {}
        }
    }
}
