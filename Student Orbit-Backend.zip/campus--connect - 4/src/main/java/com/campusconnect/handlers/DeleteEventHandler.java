package com.campusconnect.handlers;

import com.campusconnect.service.EventService;
import com.campusconnect.util.JsonUtil;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.IOException;

public class DeleteEventHandler implements HttpHandler {

    private final EventService eventService = new EventService();

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        if (!"DELETE".equalsIgnoreCase(exchange.getRequestMethod())) {
            JsonUtil.sendJsonResponse(exchange, 405, "Method Not Allowed");
            return;
        }

        try {
            String path = exchange.getRequestURI().getPath();
            String eventId = path.substring(path.lastIndexOf("/") + 1);

            boolean deleted = eventService.deleteEvent(eventId);
            if (deleted) {
                JsonUtil.sendJsonResponse(exchange, 200, "Event deleted successfully");
            } else {
                JsonUtil.sendJsonResponse(exchange, 404, "Event not found or failed to delete");
            }
        } catch (Exception e) {
            e.printStackTrace();
            JsonUtil.sendJsonResponse(exchange, 500, "Internal server error");
        }
    }
}
