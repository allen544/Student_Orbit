package com.campusconnect.handlers;

import com.campusconnect.model.Event;
import com.campusconnect.service.EventService;
import com.campusconnect.util.JsonUtil;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.InputStreamReader;
import java.net.URI;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class EventHandler implements HttpHandler {

    private final ObjectMapper mapper = new ObjectMapper();
    private final EventService eventService = new EventService();

    @Override
    public void handle(HttpExchange exchange) {
        try {
            addCorsHeaders(exchange);

            String method = exchange.getRequestMethod();

            if ("OPTIONS".equalsIgnoreCase(method)) {
                exchange.sendResponseHeaders(204, -1); // Preflight response
                return;
            }

            switch (method.toUpperCase()) {
                case "POST":
                    handleCreateEvent(exchange);
                    break;
                case "GET":
                    handleGetEvents(exchange);
                    break;
                default:
                    JsonUtil.sendJsonResponse(exchange, 405,
                            Collections.singletonMap("error", "Method not allowed"));
            }
        } catch (Exception e) {
            e.printStackTrace();
            try {
                JsonUtil.sendJsonResponse(exchange, 500,
                        Collections.singletonMap("error", "Internal server error"));
            } catch (Exception ignored) {}
        }
    }

    private void handleCreateEvent(HttpExchange exchange) throws Exception {
        Event event = mapper.readValue(
                new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8),
                Event.class
        );

        if (event.getTitle() == null || event.getTitle().trim().isEmpty()) {
            JsonUtil.sendJsonResponse(exchange, 400,
                    Collections.singletonMap("error", "Event title is required"));
            return;
        }

        eventService.saveEvent(event); // Saves to MongoDB

        JsonUtil.sendJsonResponse(exchange, 200,
                Collections.singletonMap("message", "Event created successfully"));
    }

    private void handleGetEvents(HttpExchange exchange) throws Exception {
        URI uri = exchange.getRequestURI();
        Map<String, String> queryParams = parseQueryParams(uri.getQuery());

        String department = queryParams.get("department");
        String search = queryParams.get("search");

        List<Event> filteredEvents = eventService.getFilteredEvents(department, search);

        Map<String, Object> response = new HashMap<>();
        response.put("events", filteredEvents);

        JsonUtil.sendJsonResponse(exchange, 200, response);
    }

    private Map<String, String> parseQueryParams(String query) {
        Map<String, String> map = new HashMap<>();
        if (query == null || query.trim().isEmpty()) return map;

        for (String param : query.split("&")) {
            String[] pair = param.split("=");
            if (pair.length == 2) {
                try {
                    map.put(
                            URLDecoder.decode(pair[0], StandardCharsets.UTF_8.name()),
                            URLDecoder.decode(pair[1], StandardCharsets.UTF_8.name())
                    );
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
        return map;
    }

    private void addCorsHeaders(HttpExchange exchange) {
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
        exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type");

    }
}
