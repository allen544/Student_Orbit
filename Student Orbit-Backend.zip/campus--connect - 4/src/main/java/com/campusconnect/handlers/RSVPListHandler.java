package com.campusconnect.handlers;

import com.campusconnect.db.MongoConnector;
import com.campusconnect.util.JsonUtil;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import org.bson.Document;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class RSVPListHandler implements HttpHandler {

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        // ✅ Set proper CORS headers (using set(), not add())
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, OPTIONS");
        exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type");

        // ✅ Handle preflight OPTIONS request
        if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(204, -1); // No Content
            return;
        }

        if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
            JsonUtil.sendJsonResponse(exchange, 405, "Method Not Allowed");
            return;
        }

        try {
            String path = exchange.getRequestURI().getPath();
            String eventId = path.substring(path.lastIndexOf("/") + 1);

            MongoDatabase db = MongoConnector.getDatabase();
            MongoCollection<Document> rsvpCollection = db.getCollection("rsvps");

            List<Document> rsvps = rsvpCollection.find(Filters.eq("eventId", eventId)).into(new ArrayList<>());

            JsonUtil.sendJsonResponse(exchange, 200, rsvps);

        } catch (Exception e) {
            e.printStackTrace();
            JsonUtil.sendJsonResponse(exchange, 500, "Internal server error");
        }
    }
}
