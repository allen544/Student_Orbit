package com.campusconnect.service;

import com.campusconnect.db.MongoConnector;
import com.campusconnect.model.Event;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Updates;
import org.bson.Document;
import org.bson.conversions.Bson;
import org.bson.types.ObjectId;

import java.util.ArrayList;
import java.util.List;

public class EventService {

    private final MongoCollection<Document> eventCollection;

    public EventService() {
        MongoDatabase db = MongoConnector.getDatabase();
        this.eventCollection = db.getCollection("events");
    }

    public List<Event> getAllEvents() {
        List<Event> events = new ArrayList<>();
        for (Document doc : eventCollection.find()) {
            events.add(Event.fromDocument(doc));
        }
        return events;
    }

    public List<Event> getFilteredEvents(String department, String search) {
        List<Event> events = new ArrayList<>();
        Bson departmentFilter = department != null
                ? Filters.eq("department", department)
                : Filters.exists("department");

        Bson searchFilter = search != null
                ? Filters.regex("title", ".*" + search + ".*", "i")
                : Filters.exists("title");

        Bson query = Filters.and(departmentFilter, searchFilter);

        for (Document doc : eventCollection.find(query)) {
            events.add(Event.fromDocument(doc));
        }
        return events;
    }

    public Event getEventByTitle(String title) {
        Document doc = eventCollection.find(Filters.eq("title", title)).first();
        if (doc != null) {
            return Event.fromDocument(doc);
        }
        return null;
    }

    public Event getEventById(String eventId) {


        try {
            Document doc = eventCollection.find(Filters.eq("_id", new ObjectId(eventId))).first();
            if (doc != null) {
                return Event.fromDocument(doc);
            }
        } catch (Exception e) {
            System.err.println("Error in getEventById: " + e.getMessage());
        }
        return null;
    }

    public void saveEvent(Event event) {
        Document doc = new Document("title", event.getTitle())
                .append("desc", event.getDesc())
                .append("department", event.getDepartment())
                .append("location", event.getLocation())
                .append("date", event.getDate())
                .append("time", event.getTime())
                .append("image", event.getImage())
                .append("level", event.getLevel())
                .append("startDate", event.getStartDate())
                .append("endDate", event.getEndDate())
                .append("registrationStart", event.getRegistrationStart())
                .append("registrationEnd", event.getRegistrationEnd())
                .append("status", event.getStatus())
                .append("rsvpEnabled", event.isRsvpEnabled());

        eventCollection.insertOne(doc);
    }

    public boolean updateEvent(String id, Event event) {
        try {
            Bson filter = Filters.eq("_id", new ObjectId(id));
            Bson update = Updates.combine(
                    Updates.set("title", event.getTitle()),
                    Updates.set("desc", event.getDesc()),
                    Updates.set("department", event.getDepartment()),
                    Updates.set("location", event.getLocation()),
                    Updates.set("date", event.getDate()),
                    Updates.set("time", event.getTime()),
                    Updates.set("image", event.getImage()),
                    Updates.set("level", event.getLevel()),
                    Updates.set("startDate", event.getStartDate()),
                    Updates.set("endDate", event.getEndDate()),
                    Updates.set("registrationStart", event.getRegistrationStart()),
                    Updates.set("registrationEnd", event.getRegistrationEnd()),
                    Updates.set("status", event.getStatus()),
                    Updates.set("rsvpEnabled", event.isRsvpEnabled())
            );
            eventCollection.updateOne(filter, update);
            return true;
        } catch (Exception e) {
            System.err.println("Error updating event: " + e.getMessage());
            return false;
        }
    }

    public boolean deleteEvent(String id) {
        try {
            Bson filter = Filters.eq("_id", new ObjectId(id));
            eventCollection.deleteOne(filter);
            return true;
        } catch (Exception e) {
            System.err.println("Error deleting event: " + e.getMessage());
            return false;
        }
    }

    public boolean updateStatus(String id, String status) {
        try {
            Bson filter = Filters.eq("_id", new ObjectId(id));
            eventCollection.updateOne(filter, Updates.set("status", status));
            return true;
        } catch (Exception e) {
            System.err.println("Error updating status: " + e.getMessage());
            return false;
        }
    }

    public boolean toggleRsvp(String id, boolean enabled) {
        try {
            Bson filter = Filters.eq("_id", new ObjectId(id));
            eventCollection.updateOne(filter, Updates.set("rsvpEnabled", enabled));
            return true;
        } catch (Exception e) {
            System.err.println("Error toggling RSVP: " + e.getMessage());
            return false;
        }
    }
}
