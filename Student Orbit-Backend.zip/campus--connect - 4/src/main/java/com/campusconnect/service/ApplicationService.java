package com.campusconnect.service;

import com.campusconnect.db.MongoConnector;
import com.campusconnect.model.LeaveApplication;
import com.campusconnect.model.OnDutyApplication;
import com.mongodb.client.MongoCollection;
import org.bson.Document;

public class ApplicationService {

    private final MongoCollection<Document> leaveCollection;
    private final MongoCollection<Document> dutyCollection;

    public ApplicationService() {
        this.leaveCollection = MongoConnector.getDatabase().getCollection("leave_applications");
        this.dutyCollection = MongoConnector.getDatabase().getCollection("duty_applications");
    }

    public void saveLeaveApplication(LeaveApplication app) {
        Document doc = new Document()
                .append("name", app.getName())
                .append("class", app.getClassName())
                .append("from", app.getFrom())
                .append("to", app.getTo())
                .append("reason", app.getReason())
                .append("file", app.getFile())
                .append("status", app.getStatus());

        leaveCollection.insertOne(doc);
    }

    public void saveOnDutyApplication(OnDutyApplication app) {
        Document doc = new Document("name", app.getName())
                .append("event", app.getEvent())
                .append("date", app.getDate())
                .append("file", app.getFileName())
                .append("slots", app.getTimeSlots())
                .append("status", "Pending");

        dutyCollection.insertOne(doc);
    }
}
