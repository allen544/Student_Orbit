package com.campusconnect.service;

import com.campusconnect.model.RSVP;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import java.time.Instant;
import java.util.Map;

import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;
import static com.mongodb.client.model.Updates.*;

public class RSVPService {

    private final MongoCollection<Document> rsvpCollection;

    public RSVPService() {
        MongoClient client = MongoClients.create("mongodb://localhost:27017");
        MongoDatabase db = client.getDatabase("campusconnect");
        this.rsvpCollection = db.getCollection("rsvp");
    }

    public String handleRSVP(Map<String, Object> data) {
        String name = (String) data.get("name");
        String email = (String) data.get("email");
        String eventTitle = (String) data.get("eventTitle");
        String status = (String) data.get("status");
        String venue = (String) data.get("venue");
        String date = (String) data.get("date");


        if (name == null || email == null || eventTitle == null || status == null) {
            return "Missing required RSVP fields";
        }

        Document filter = new Document("email", email).append("eventTitle", eventTitle);
        Document update = new Document("$set", new Document()
                .append("fullName", name)
                .append("email", email)
                .append("eventTitle", eventTitle)
                .append("status", status)
                .append("venue", venue)
                .append("date", date)
                .append("timestamp", Instant.now().toString())
        );

        rsvpCollection.updateOne(filter, update, new com.mongodb.client.model.UpdateOptions().upsert(true));
        return "RSVP recorded";
    }
}
