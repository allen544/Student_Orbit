package com.campusconnect.service;

import com.campusconnect.db.MongoConnector;
import com.campusconnect.model.User;
import com.campusconnect.util.PasswordUtil; // ✅ Add this
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

public class AuthService {

    private final MongoCollection<Document> userCollection;

    public AuthService() {
        MongoDatabase db = MongoConnector.getDatabase();
        this.userCollection = db.getCollection("users");
    }

    public String registerUser(User user) {
        Document existing = userCollection.find(new Document("email", user.getEmail())).first();
        if (existing != null) {
            return "User already exists with this email.";
        }

        Document doc = new Document("fullName", user.getFullName())
                .append("email", user.getEmail())
                .append("password", PasswordUtil.hashPassword(user.getPassword()))
                .append("department", user.getDepartment())
                .append("semester", user.getSemester());

        userCollection.insertOne(doc);
        return "User registered successfully.";
    }
}
