package com.campusconnect.util;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class OtpStore {

    private static class OtpEntry {
        private final String otp;
        private final long expiryTime;

        public OtpEntry(String otp, long expiryTime) {
            this.otp = otp;
            this.expiryTime = expiryTime;
        }

        public String getOtp() {
            return otp;
        }

        public long getExpiryTime() {
            return expiryTime;
        }
    }

    private static final Map<String, OtpEntry> otpMap = new ConcurrentHashMap<>();
    private static final long EXPIRY_DURATION = 5 * 60 * 1000; // 5 minutes

    public static void storeOtp(String email, String otp) {
        long expiryTime = System.currentTimeMillis() + EXPIRY_DURATION;
        otpMap.put(email, new OtpEntry(otp, expiryTime));
    }

    public static String getOtp(String email) {
        OtpEntry entry = otpMap.get(email);
        if (entry == null) return null;

        if (System.currentTimeMillis() > entry.getExpiryTime()) {
            otpMap.remove(email);
            return null;
        }
        return entry.getOtp();
    }

    public static void removeOtp(String email) {
        otpMap.remove(email);
    }

    public static void cleanupExpiredOtps() {
        long now = System.currentTimeMillis();
        otpMap.entrySet().removeIf(entry -> now > entry.getValue().getExpiryTime());
    }
}
