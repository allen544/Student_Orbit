package com.campusconnect.util;

import com.campusconnect.model.Event;

import javax.mail.*;
import javax.mail.internet.*;
import java.util.Properties;

public class EmailUtil {

    private static final String FROM_EMAIL = "joicegrge2002@gmail.com";
    private static final String APP_PASSWORD = "kqbt yvlr sgld zyza";

    public static void sendEmail(String to, String subject, String body) throws MessagingException {
        System.out.println("Preparing to send email to: " + to);

        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        System.out.println("Creating mail session...");
        Session session = Session.getInstance(props, new Authenticator() {
            protected PasswordAuthentication getPasswordAuthentication() {
                System.out.println("Authenticating with email: " + FROM_EMAIL);
                return new PasswordAuthentication(FROM_EMAIL, APP_PASSWORD);
            }
        });

        System.out.println("Creating message...");
        Message message = new MimeMessage(session);
        message.setFrom(new InternetAddress(FROM_EMAIL));
        message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
        message.setSubject(subject);
        message.setText(body);

        System.out.println("Sending message...");
        Transport.send(message);
        System.out.println("✅ Email sent successfully to " + to);
    }

    public static void sendOtpEmail(String to, String otp) throws MessagingException {
        String subject = "Your OTP Code";
        String body = "Your OTP code is: " + otp + "\nIt will expire in 5 minutes.";
        sendEmail(to, subject, body);
    }

    public static boolean testEmailConfiguration() {
        try {
            sendEmail("joicegrge2002@gmail.com", "Test Email", "This is a test email.");
            return true;
        } catch (Exception e) {
            System.err.println("❌ Failed to send test email: " + e.getMessage());
            return false;
        }
    }

    // ✅ New method: send RSVP confirmation
    public static void sendConfirmation(String to, Event event) {
        String subject = "RSVP Confirmation for " + event.getTitle();
        String body = "Hi,\n\n" +
                "Thank you for RSVPing to the event \"" + event.getTitle() + "\".\n\n" +
                "📅 Date: " + event.getDate() + "\n" +
                "⏰ Time: " + event.getTime() + "\n" +
                "📍 Venue: " + event.getLocation() + "\n\n" +
                "We look forward to seeing you there!\n\n" +
                "- Campus Connect Team";

        try {
            sendEmail(to, subject, body);
        } catch (MessagingException e) {
            System.err.println("❌ Failed to send confirmation email: " + e.getMessage());
        }
    }
}
