package com.campusconnect;

import com.campusconnect.handlers.*;
import com.campusconnect.util.OtpStore;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class Main {
    public static void main(String[] args) throws Exception {
        // 🌐 Create HTTP server
        HttpServer server = HttpServer.create(new InetSocketAddress("0.0.0.0", 8080), 0);

        // ✅ Auth Routes with CORS
        server.createContext("/api/auth/signup", new CorsHandler(new SignupHandler()));
        server.createContext("/api/auth/login", new CorsHandler(new LoginHandler()));
        server.createContext("/api/auth/forgot-password/send-code", new CorsHandler(new SendCodeHandler()));
        server.createContext("/api/auth/forgot-password/verify-code", new CorsHandler(new VerifyCodeHandler()));
        server.createContext("/api/auth/forgot-password/reset", new CorsHandler(new ResetPasswordHandler()));

        // ✅ Event Management
        server.createContext("/api/events", new CorsHandler(new EventHandler())); // GET & POST
        server.createContext("/api/events/id", new CorsHandler(new GetEventByIdHandler())); // GET by ID

        // Optional: You can remove this if not needed
        // server.createContext("/get-event-by-id", new GetEventByIdHandler());

        // ✅ RSVP Related
        server.createContext("/events/update", new CorsHandler(new UpdateEventHandler()));           // PUT /events/update/{id}
        server.createContext("/api/events/", new CorsHandler(new DeleteEventHandler()));             // DELETE /events/{id}
        server.createContext("/events/status", new CorsHandler(new ChangeStatusHandler()));          // PATCH /events/status/{id}
        server.createContext("/events/rsvp-stats", new CorsHandler(new RSVPStatsHandler()));         // GET /events/rsvp-stats/{id}
        server.createContext("/events/rsvp-list", new CorsHandler(new RSVPListHandler()));           // GET /events/rsvp-list/{id}
        server.createContext("/events", new CorsHandler(new EventHandler()));
        server.createContext("/rsvp", new RSVPHandler());



        // GET all events
        server.createContext("/events/", new GetEventByIdHandler());


        server.createContext("/admin/absences", new CorsHandler(new GetAbsencesHandler()));





        // ✅ Leave/Duty Application
        server.createContext("/api/absence/leave", new CorsHandler(new LeaveApplicationHandler()));
        server.createContext("/api/absence/duty", new CorsHandler(new OnDutyApplicationHandler()));

        // 🔧 Thread Pool
        server.setExecutor(Executors.newFixedThreadPool(10));

        // 🧹 Schedule OTP cleanup task every 5 min
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
        scheduler.scheduleAtFixedRate(() -> {
            try {
                OtpStore.cleanupExpiredOtps();
            } catch (Exception e) {
                System.err.println("Error during OTP cleanup: " + e.getMessage());
            }
        }, 5, 5, TimeUnit.MINUTES);

        // 🚀 Start server
        server.start();
        System.out.println("⚡ Server running at http://localhost:8080");
        System.out.println("🧹 OTP cleanup task scheduled every 5 minutes");
        System.out.println("🛡️  CORS support enabled for all endpoints");

        // 🔒 Shutdown hook
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            System.out.println("🛑 Shutting down server...");
            server.stop(0);
            scheduler.shutdown();
        }));
    }

    // 🌐 Global CORS Middleware
    private static class CorsHandler implements HttpHandler {
        private final HttpHandler innerHandler;

        public CorsHandler(HttpHandler innerHandler) {
            this.innerHandler = innerHandler;
        }

        @Override
        public void handle(HttpExchange exchange) throws IOException {
            exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
            exchange.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, PATCH, OPTIONS");
            exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type, Authorization");
            exchange.getResponseHeaders().set("Access-Control-Allow-Credentials", "true");
            exchange.getResponseHeaders().set("Access-Control-Max-Age", "3600");
            exchange.getResponseHeaders().add("Access-Control-Allow-Headers", "Content-Type");

            if (exchange.getRequestMethod().equalsIgnoreCase("OPTIONS")) {
                exchange.sendResponseHeaders(204, -1);
                return;
            }

            innerHandler.handle(exchange);
        }
    }
}
