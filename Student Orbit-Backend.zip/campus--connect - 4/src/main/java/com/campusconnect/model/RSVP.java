package com.campusconnect.model;

import org.bson.Document;
import java.time.Instant;

public class RSVP {
    private String eventTitle;
    private String name;
    private String email;
    private String status;
    private String venue;
    private String date;
    private Instant timestamp;

    public RSVP() {}

    public RSVP(String eventTitle, String name, String email, String status, String venue, String date, Instant timestamp) {
        this.eventTitle = eventTitle;
        this.name = name;
        this.email = email;
        this.status = status;
        this.venue = venue;
        this.date = date;
        this.timestamp = timestamp;
    }

    public Document toDocument() {
        return new Document("eventTitle", eventTitle)
                .append("name", name)
                .append("email", email)
                .append("status", status)
                .append("venue", venue)
                .append("date", date)
                .append("timestamp", timestamp != null ? timestamp.toString() : Instant.now().toString());
    }

    public String getEventTitle() { return eventTitle; }
    public void setEventTitle(String eventTitle) { this.eventTitle = eventTitle; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getVenue() { return venue; }
    public void setVenue(String venue) { this.venue = venue; }

    public String getDate() { return date; }
    public void setDate(String date) { this.date = date; }

    public Instant getTimestamp() { return timestamp; }
    public void setTimestamp(Instant timestamp) { this.timestamp = timestamp; }

    public void setTimestamp(String timestamp) {
        this.timestamp = Instant.parse(timestamp);
    }
}
