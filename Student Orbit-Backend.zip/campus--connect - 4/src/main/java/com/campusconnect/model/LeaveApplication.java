// LeaveApplication.java
package com.campusconnect.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class LeaveApplication {
    private String name;
    @JsonProperty("class")
    private String className;
    private String from;
    private String to;
    private String reason;
    private String file;
    private String status;

    public LeaveApplication() {}

    public LeaveApplication(String name, String className, String from, String to, String reason, String file, String status) {
        this.name = name;
        this.className = className;
        this.from = from;
        this.to = to;
        this.reason = reason;
        this.file = file;
        this.status = status;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getFrom() {
        return from;
    }

    public void setFrom(String from) {
        this.from = from;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getFile() {
        return file;
    }

    public void setFile(String file) {
        this.file = file;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}