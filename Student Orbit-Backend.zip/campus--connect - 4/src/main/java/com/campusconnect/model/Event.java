package com.campusconnect.model;

import org.bson.Document;

public class Event {
    private String id;
    private String title;
    private String desc;
    private String department;
    private String level;
    private String location;
    private String date;
    private String time;
    private String image;
    private String startDate;
    private String endDate;
    private String registrationStart;
    private String registrationEnd;

    // ✅ New fields for admin
    private String status;         // draft / upcoming / published
    private boolean rsvpEnabled;   // enable RSVP or not

    public Event() {}

    public Event(String title, String desc, String department, String location, String date, String time, String image) {
        this.title = title;
        this.desc = desc;
        this.department = department;
        this.location = location;
        this.date = date;
        this.time = time;
        this.image = image;
    }

    // Getters
    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getDesc() { return desc; }
    public String getDepartment() { return department; }
    public String getLevel() { return level; }
    public String getLocation() { return location; }
    public String getDate() { return date; }
    public String getTime() { return time; }
    public String getImage() { return image; }
    public String getStartDate() { return startDate; }
    public String getEndDate() { return endDate; }
    public String getRegistrationStart() { return registrationStart; }
    public String getRegistrationEnd() { return registrationEnd; }
    public String getStatus() { return status; }
    public boolean isRsvpEnabled() { return rsvpEnabled; }

    // Setters
    public void setId(String id) { this.id = id; }
    public void setTitle(String title) { this.title = title; }
    public void setDesc(String desc) { this.desc = desc; }
    public void setDepartment(String department) { this.department = department; }
    public void setLevel(String level) { this.level = level; }
    public void setLocation(String location) { this.location = location; }
    public void setDate(String date) { this.date = date; }
    public void setTime(String time) { this.time = time; }
    public void setImage(String image) { this.image = image; }
    public void setStartDate(String startDate) { this.startDate = startDate; }
    public void setEndDate(String endDate) { this.endDate = endDate; }
    public void setRegistrationStart(String registrationStart) { this.registrationStart = registrationStart; }
    public void setRegistrationEnd(String registrationEnd) { this.registrationEnd = registrationEnd; }
    public void setStatus(String status) { this.status = status; }
    public void setRsvpEnabled(boolean rsvpEnabled) { this.rsvpEnabled = rsvpEnabled; }

    public static Event fromDocument(Document doc) {
        Event event = new Event();
        event.setId(doc.getObjectId("_id").toString());
        event.setTitle(doc.getString("title"));
        event.setDesc(doc.getString("desc"));
        event.setDate(doc.getString("date"));
        event.setTime(doc.getString("time"));
        event.setLocation(doc.getString("location"));
        event.setDepartment(doc.getString("department"));
        event.setImage(doc.getString("image"));
        event.setLevel(doc.getString("level"));
        event.setStartDate(doc.getString("startDate"));
        event.setEndDate(doc.getString("endDate"));
        event.setRegistrationStart(doc.getString("registrationStart"));
        event.setRegistrationEnd(doc.getString("registrationEnd"));
        event.setStatus(doc.getString("status"));
        event.setRsvpEnabled(doc.getBoolean("rsvpEnabled", false)); // default false
        return event;
    }
}
