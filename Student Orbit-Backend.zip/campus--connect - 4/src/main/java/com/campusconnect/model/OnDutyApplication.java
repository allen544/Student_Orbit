package com.campusconnect.model;

import com.fasterxml.jackson.annotation.JsonProperty;

public class OnDutyApplication {
    private String name;
    private String event;
    private String date;
    @JsonProperty("file")
    private String fileName;
    @JsonProperty("slots")
    private String timeSlots;
    @JsonProperty("status")
    private String status;

    public OnDutyApplication() {}

    // Getters
    public String getName() {
        return name;
    }

    public String getEvent() {
        return event;
    }

    public String getDate() {
        return date;
    }

    public String getFileName() {
        return fileName;
    }

    public String getTimeSlots() {
        return timeSlots;
    }
    public String getStatus() {
        return status;
    }

    // Setters
    public void setName(String name) {
        this.name = name;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public void setTimeSlots(String timeSlots) {
        this.timeSlots = timeSlots;
    }
    public void setStatus(String status) {
        this.status = status;
    }
}
