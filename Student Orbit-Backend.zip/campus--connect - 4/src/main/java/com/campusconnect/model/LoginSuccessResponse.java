package com.campusconnect.model;

import java.util.HashMap;
import java.util.Map;

public class LoginSuccessResponse {
    private String token;
    private Map<String, String> user;

    public LoginSuccessResponse(String token, String id, String fullName, String email, String department, String semester) {
        this.token = token;
        this.user = new HashMap<>();
        this.user.put("id", id);
        this.user.put("fullName", fullName);
        this.user.put("email", email);
        this.user.put("department", department);
        this.user.put("semester", semester);
    }


    // Getters are required for Jackson serialization
    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public Map<String, String> getUser() {
        return user;
    }

    public void setUser(Map<String, String> user) {
        this.user = user;
    }
}